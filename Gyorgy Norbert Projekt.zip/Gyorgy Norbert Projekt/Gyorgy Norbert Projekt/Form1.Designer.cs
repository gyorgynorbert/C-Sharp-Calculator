﻿namespace Gyorgy_Norbert_Projekt
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_zero = new System.Windows.Forms.Button();
            this.button_dot = new System.Windows.Forms.Button();
            this.button_equals = new System.Windows.Forms.Button();
            this.btn_one = new System.Windows.Forms.Button();
            this.btn_two = new System.Windows.Forms.Button();
            this.btn_three = new System.Windows.Forms.Button();
            this.btn_plus = new System.Windows.Forms.Button();
            this.btn_four = new System.Windows.Forms.Button();
            this.btn_five = new System.Windows.Forms.Button();
            this.btn_six = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_seven = new System.Windows.Forms.Button();
            this.btn_eight = new System.Windows.Forms.Button();
            this.btn_nine = new System.Windows.Forms.Button();
            this.btn_times = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_divide = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_zero
            // 
            this.btn_zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_zero.Location = new System.Drawing.Point(9, 522);
            this.btn_zero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_zero.Name = "btn_zero";
            this.btn_zero.Size = new System.Drawing.Size(208, 92);
            this.btn_zero.TabIndex = 1;
            this.btn_zero.Text = "0";
            this.btn_zero.UseVisualStyleBackColor = true;
            this.btn_zero.Click += new System.EventHandler(this.btn_zero_Click);
            // 
            // button_dot
            // 
            this.button_dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_dot.Location = new System.Drawing.Point(225, 522);
            this.button_dot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_dot.Name = "button_dot";
            this.button_dot.Size = new System.Drawing.Size(100, 92);
            this.button_dot.TabIndex = 2;
            this.button_dot.Text = ".";
            this.button_dot.UseVisualStyleBackColor = true;
            // 
            // button_equals
            // 
            this.button_equals.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_equals.Location = new System.Drawing.Point(333, 422);
            this.button_equals.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_equals.Name = "button_equals";
            this.button_equals.Size = new System.Drawing.Size(100, 192);
            this.button_equals.TabIndex = 3;
            this.button_equals.Text = "=";
            this.button_equals.UseVisualStyleBackColor = true;
            this.button_equals.Click += new System.EventHandler(this.button_equals_Click);
            // 
            // btn_one
            // 
            this.btn_one.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_one.Location = new System.Drawing.Point(9, 422);
            this.btn_one.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_one.Name = "btn_one";
            this.btn_one.Size = new System.Drawing.Size(100, 92);
            this.btn_one.TabIndex = 4;
            this.btn_one.Text = "1";
            this.btn_one.UseVisualStyleBackColor = true;
            this.btn_one.Click += new System.EventHandler(this.btn_one_Click);
            // 
            // btn_two
            // 
            this.btn_two.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_two.Location = new System.Drawing.Point(117, 422);
            this.btn_two.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_two.Name = "btn_two";
            this.btn_two.Size = new System.Drawing.Size(100, 92);
            this.btn_two.TabIndex = 5;
            this.btn_two.Text = "2";
            this.btn_two.UseVisualStyleBackColor = true;
            this.btn_two.Click += new System.EventHandler(this.btn_two_Click_1);
            // 
            // btn_three
            // 
            this.btn_three.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_three.Location = new System.Drawing.Point(225, 422);
            this.btn_three.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_three.Name = "btn_three";
            this.btn_three.Size = new System.Drawing.Size(100, 92);
            this.btn_three.TabIndex = 6;
            this.btn_three.Text = "3";
            this.btn_three.UseVisualStyleBackColor = true;
            this.btn_three.Click += new System.EventHandler(this.btn_three_Click_1);
            // 
            // btn_plus
            // 
            this.btn_plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_plus.Location = new System.Drawing.Point(333, 227);
            this.btn_plus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(100, 187);
            this.btn_plus.TabIndex = 7;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = true;
            this.btn_plus.Click += new System.EventHandler(this.btn_plus_Click);
            // 
            // btn_four
            // 
            this.btn_four.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_four.Location = new System.Drawing.Point(9, 322);
            this.btn_four.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_four.Name = "btn_four";
            this.btn_four.Size = new System.Drawing.Size(100, 92);
            this.btn_four.TabIndex = 8;
            this.btn_four.Text = "4";
            this.btn_four.UseVisualStyleBackColor = true;
            this.btn_four.Click += new System.EventHandler(this.btn_four_Click);
            // 
            // btn_five
            // 
            this.btn_five.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_five.Location = new System.Drawing.Point(117, 322);
            this.btn_five.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_five.Name = "btn_five";
            this.btn_five.Size = new System.Drawing.Size(100, 92);
            this.btn_five.TabIndex = 9;
            this.btn_five.Text = "5";
            this.btn_five.UseVisualStyleBackColor = true;
            this.btn_five.Click += new System.EventHandler(this.btn_five_Click_1);
            // 
            // btn_six
            // 
            this.btn_six.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_six.Location = new System.Drawing.Point(225, 322);
            this.btn_six.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_six.Name = "btn_six";
            this.btn_six.Size = new System.Drawing.Size(100, 92);
            this.btn_six.TabIndex = 10;
            this.btn_six.Text = "6";
            this.btn_six.UseVisualStyleBackColor = true;
            this.btn_six.Click += new System.EventHandler(this.btn_six_Click);
            // 
            // btn_minus
            // 
            this.btn_minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_minus.Location = new System.Drawing.Point(333, 127);
            this.btn_minus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(100, 92);
            this.btn_minus.TabIndex = 11;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = true;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_Click);
            // 
            // btn_seven
            // 
            this.btn_seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_seven.Location = new System.Drawing.Point(9, 223);
            this.btn_seven.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_seven.Name = "btn_seven";
            this.btn_seven.Size = new System.Drawing.Size(100, 92);
            this.btn_seven.TabIndex = 12;
            this.btn_seven.Text = "7";
            this.btn_seven.UseVisualStyleBackColor = true;
            this.btn_seven.Click += new System.EventHandler(this.btn_seven_Click_1);
            // 
            // btn_eight
            // 
            this.btn_eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_eight.Location = new System.Drawing.Point(117, 223);
            this.btn_eight.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_eight.Name = "btn_eight";
            this.btn_eight.Size = new System.Drawing.Size(100, 92);
            this.btn_eight.TabIndex = 13;
            this.btn_eight.Text = "8";
            this.btn_eight.UseVisualStyleBackColor = true;
            this.btn_eight.Click += new System.EventHandler(this.btn_eight_Click_1);
            // 
            // btn_nine
            // 
            this.btn_nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_nine.Location = new System.Drawing.Point(225, 223);
            this.btn_nine.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_nine.Name = "btn_nine";
            this.btn_nine.Size = new System.Drawing.Size(100, 92);
            this.btn_nine.TabIndex = 14;
            this.btn_nine.Text = "9";
            this.btn_nine.UseVisualStyleBackColor = true;
            this.btn_nine.Click += new System.EventHandler(this.btn_nine_Click);
            // 
            // btn_times
            // 
            this.btn_times.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_times.Location = new System.Drawing.Point(117, 127);
            this.btn_times.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_times.Name = "btn_times";
            this.btn_times.Size = new System.Drawing.Size(100, 92);
            this.btn_times.TabIndex = 15;
            this.btn_times.Text = "x";
            this.btn_times.UseVisualStyleBackColor = true;
            this.btn_times.Click += new System.EventHandler(this.btn_times_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_clear.Location = new System.Drawing.Point(9, 127);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(100, 92);
            this.btn_clear.TabIndex = 16;
            this.btn_clear.Text = "C";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_divide
            // 
            this.btn_divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_divide.Location = new System.Drawing.Point(225, 127);
            this.btn_divide.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_divide.Name = "btn_divide";
            this.btn_divide.Size = new System.Drawing.Size(100, 92);
            this.btn_divide.TabIndex = 20;
            this.btn_divide.Text = "/";
            this.btn_divide.UseVisualStyleBackColor = true;
            this.btn_divide.Click += new System.EventHandler(this.btn_divide_Click);
            // 
            // result
            // 
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.result.Location = new System.Drawing.Point(13, 13);
            this.result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.result.Multiline = true;
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(419, 106);
            this.result.TabIndex = 21;
            this.result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(439, 629);
            this.Controls.Add(this.result);
            this.Controls.Add(this.btn_divide);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_times);
            this.Controls.Add(this.btn_nine);
            this.Controls.Add(this.btn_eight);
            this.Controls.Add(this.btn_seven);
            this.Controls.Add(this.btn_minus);
            this.Controls.Add(this.btn_six);
            this.Controls.Add(this.btn_five);
            this.Controls.Add(this.btn_four);
            this.Controls.Add(this.btn_plus);
            this.Controls.Add(this.btn_three);
            this.Controls.Add(this.btn_two);
            this.Controls.Add(this.btn_one);
            this.Controls.Add(this.button_equals);
            this.Controls.Add(this.button_dot);
            this.Controls.Add(this.btn_zero);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_zero;
        private System.Windows.Forms.Button button_dot;
        private System.Windows.Forms.Button button_equals;
        private System.Windows.Forms.Button btn_one;
        private System.Windows.Forms.Button btn_two;
        private System.Windows.Forms.Button btn_three;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.Button btn_four;
        private System.Windows.Forms.Button btn_five;
        private System.Windows.Forms.Button btn_six;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_seven;
        private System.Windows.Forms.Button btn_eight;
        private System.Windows.Forms.Button btn_nine;
        private System.Windows.Forms.Button btn_times;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_divide;
        private System.Windows.Forms.TextBox result;
    }
}

